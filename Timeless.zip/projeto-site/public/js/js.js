function clickn1(){
  n1.innerHTML = `⬤`
  n2.innerHTML = `◯`
  n3.innerHTML = `◯`
  n4.innerHTML = `◯`
}
function clickn2(){
  n1.innerHTML = `◯`
  n2.innerHTML = `⬤`
  n3.innerHTML = `◯`
  n4.innerHTML = `◯`
}
function clickn3(){
  n1.innerHTML = `◯`
  n2.innerHTML = `◯`
  n3.innerHTML = `⬤`
  n4.innerHTML = `◯`
}
function clickn4(){
  n1.innerHTML = `◯`
  n2.innerHTML = `◯`
  n3.innerHTML = `◯`
  n4.innerHTML = `⬤`
}
function textpass(){
    document.getElementById("txtmidia").classList.add('animation_textpass');
    setTimeout(function(){ 
        document.getElementById("txtmidia").classList.remove('animation_textpass');
    }, 1000);
    
}
function slidepass(){
    document.getElementById("slidetoptop").classList.add('animation_slidepass');
    setTimeout(function(){ 
        document.getElementById("slidetoptop").classList.remove('animation_slidepass');
    }, 1000);
}

function inserir(){
  txtoquee.innerHTML = oquee
  txtmaquina.innerHTML = metodos.maquina;
  txtmagia.innerHTML = metodos.magia;
  txtvelocidade.innerHTML = metodos.velocidade;
  txttaquions.innerHTML = teoria.taquions;
  txtworm.innerHTML = teoria.worm;
  txtcilindro.innerHTML = teoria.cilindro;
  txtparadoxo.innerHTML = paradoxos.geral;
  txtavo.innerHTML = paradoxos.avo;
}
var menucount = 1;
function pressmenu(){
    if(menucount == 1){
        menu.style.display = 'block'
        document.getElementById("menu").classList.add('animation_menu');
        document.getElementById("menu").classList.remove('animation_fecharmenu');
        setTimeout(function(){ menucount = 0;}, 2400);
    }
    else{
        document.getElementById("menu").classList.remove('animation_menu');
        document.getElementById("menu").classList.add('animation_fecharmenu');
        setTimeout(function(){ menu.style.display = 'none'; menucount = 1;}, 2400);
    }
}
function plusDivs(n) {
  slidershow(slideshow += n);
}

function currentDiv(n) {
  slidershow(slideshow = n);
}

function slidershow(n) {
  var i;
  var slidediv = document.getElementsByClassName("demo");
  if (n > x.length) {slideshow = 1}
  if (slideshow == 1){
    slidediv[i].style.background = "../background/doctorwho.jpg";
  }
  else if (slideshow == 3){
    slidediv[i].style.background = "../background/backtothefuture.jpg";
  }
  else if (slideshow == 3){
    slidediv[i].style.background = "../background/ocarinaoftime.jpg";
  }
}
var avo = 1;
function abriravo(){
  if(avo == 1){
    setinhadown.style.display = `none`
    setinhaup.style.display = `block`
    paradoxoavo.style.display = `block`
    document.getElementById("paradoxoavo").classList.add('animation_abrirprabaixo');
    document.getElementById("paradoxoavo").classList.remove('animation_fecharpracima');
    setTimeout(function(){ 
      avo = 0
    }, 900);
  }
  
}
function fecharavo(){
  if(avo == 0){
    setinhadown.style.display = `block`
    setinhaup.style.display = `none`
    document.getElementById("paradoxoavo").classList.remove('animation_abrirprabaixo');
    document.getElementById("paradoxoavo").classList.add('animation_fecharpracima');
    setTimeout(function(){ 
      paradoxoavo.style.display = `none`
      avo = 1
    }, 900);
  } 
}

var fimdebeck = 0
function abrirfeedback(){
  if(fimdebeck == 0){
    feedback.style.display = `block`
    tampa.style.display = `block`
    document.getElementById("feedback").classList.add('animation_abrirfeedback');
    document.getElementById("feedback").classList.remove('animation_fecharfeedback');  
    fimdebeck = 1;
    } 
  else{
    document.getElementById("feedback").classList.remove('animation_abrirfeedback');
    document.getElementById("feedback").classList.add('animation_fecharfeedback');  
    setTimeout(function(){
      feedback.style.display = `none`
      tampa.style.display = `none`
      fimdebeck = 0;
    }, 1000)
  }
    
}
function fecharfeedback(){
    document.getElementById("feedback").classList.remove('animation_abrirfeedback');
    document.getElementById("feedback").classList.add('animation_fecharfeedback');  
    setTimeout(function(){
      feedback.style.display = `none`
      tampa.style.display = `none`
      fimdebeck = 0;
    }, 1000)
}
var contatin = 0
function abrircontato(){
  if(contatin == 0){
    contato.style.display = `block`
    document.getElementById("contato").classList.add('animation_abrircontato');
    document.getElementById("contato").classList.remove('animation_fecharcontato'); 
    contatin = 1;
  } 
  else{
    document.getElementById("contato").classList.remove('animation_abrircontato');
    document.getElementById("contato").classList.add('animation_fecharcontato');  
    setTimeout(function(){
      contato.style.display = `none`;
      contatin = 0;
    }, 1000)
      document.getElementById("zap").classList.remove('animation_abrirzipzop');
      document.getElementById("zap").classList.add('animation_fecharzipzop');  
      setTimeout(function(){
        zap.style.display = `none`;
        zepeto = 0;
      }, 1000)
  }
}
var zepeto = 0;
function zapzap(){
  if(zepeto == 0){
    zap.style.display = `block`
    document.getElementById("zap").classList.add('animation_abrirzipzop');
    document.getElementById("zap").classList.remove('animation_fecharzipzop'); 
    zepeto = 1;
  } 
  else{
    document.getElementById("zap").classList.remove('animation_abrirzipzop');
    document.getElementById("zap").classList.add('animation_fecharzipzop');  
    setTimeout(function(){
      zap.style.display = `none`;
      zepeto = 0;
    }, 1000)
  }
}
var video = 0;
function abrirvideo(){
  if(video == 0){
    tropia.style.display = `block`
    document.getElementById("tropia").classList.add('animation_abrirvideo');
    document.getElementById("tropia").classList.remove('animation_fecharvideo'); 
    video = 1;
  } 
  else{
    document.getElementById("tropia").classList.remove('animation_abrirvideo');
    document.getElementById("tropia").classList.add('animation_fecharvideo');  
    setTimeout(function(){
      tropia.style.display = `none`;
      video = 0;
    }, 900)
  }
}
function feedbackBD(){
    var erros = validacao();
    errormsg.innerHTML = "";

    if(erros.length > 0){
    for(var i=0; i < erros.length; i++){
        var erro = erros[i];
        var li = document.createElement("li");
        li.innerHTML = erro;
        errormsg.appendChild(li);
    }
    }else{
    // Código que envia os dados
    // para o BD
    }       
    }
    function validacao(){
    var erros = [];

    if(!nome.value || 
        (nome.value.toIndex("1") != -1) ||
        (nome.value.toIndex("2") != -1) ||
        (nome.value.toIndex("3") != -1) ||
        (nome.value.toIndex("4") != -1) ||
        (nome.value.toIndex("5") != -1) ||
        (nome.value.toIndex("6") != -1) ||
        (nome.value.toIndex("7") != -1) ||
        (nome.value.toIndex("8") != -1) ||
        (nome.value.toIndex("9") != -1) ||
        (nome.value.toIndex("#") != -1) ||
        (nome.value.toIndex("@") != -1)){
    erros.push("Prencha seu nome");
    }

    if(!email.value ||
        (email.value.toIndex("@") == -1) ||
        (email.value.toIndex(".") == -1) ||
        (email.value.toIndex(" ") != -1)){
    erros.push("O formato do email é: usuario@dominio.com");
    }

    if(!retorno.value){
    erros.push("Preencha seu feedback")
    }
    return erros;
}