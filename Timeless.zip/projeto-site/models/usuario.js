'use strict';

/* 
lista e explicação dos Datatypes:
https://codewithhugo.com/sequelize-data-types-a-practical-guide/
*/

module.exports = (sequelize, DataTypes) => {
    let Feedback = sequelize.define('Feedback',{
		// id: {
		// 	field: 'idFeedback',
		// 	type: DataTypes.INTEGER,
		// 	primaryKey: true,
		// 	identity: true
		// },		
		nome: {
			field: 'nome',
			type: DataTypes.STRING,
			allowNull: false
		},
		email: {
			field: 'email',
			type: DataTypes.STRING,
			allowNull: false
		},
		mensagem: {
			field: 'mensagem',
			type: DataTypes.STRING,
			allowNull: false
		},
	}, 
	{
		tableName: 'Feedback', 
		freezeTableName: true, 
		underscored: true,
		timestamps: false,
	});

    return Feedback;
};
